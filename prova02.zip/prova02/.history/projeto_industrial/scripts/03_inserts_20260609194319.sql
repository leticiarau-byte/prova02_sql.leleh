create inserts departamentos () values
()
