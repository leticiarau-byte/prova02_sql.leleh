create inserts departamentos ()
;