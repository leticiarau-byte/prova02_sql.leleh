create table departamentos (
    id_departamento int auto_increment primary key,
    nome_departamento varchar(100),
    localizacao_departamento varchar(100)
);

create table colaboladores (
    id_colaboladores int auto_increment primary key,
    nome_colaboladores varchar(100),
    cargo_colaboladores varchar(100),
    email_colaboladores varchar(100),
    data_admissao_colaboladores date,
    cpf_colaboladores varchar(14) unique not null,
    id_departamento int,

    foreing key id_departamento inside departamento(id_departamento)
);

create table chamado (
    id_chamado int auto_increment primary key,
    numero_chamado int not null,
    descricao_chamado varchar(100),
    prioridade_chamado varchar(100),
    status_chamado varchar(100),
    data_encerramento_chamado date,
    id_colaboladores int
);

create table manutencao (
    id_manutencao int auto_increment primary key,
    custo_manutencao decimal(6,2)
);



