create table departamentos (
    id_departamento int
)