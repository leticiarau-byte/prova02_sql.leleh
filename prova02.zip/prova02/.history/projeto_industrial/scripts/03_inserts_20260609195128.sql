use 
create inserts departamentos () values
()
