create table departamentos (
    id_equipamento
)