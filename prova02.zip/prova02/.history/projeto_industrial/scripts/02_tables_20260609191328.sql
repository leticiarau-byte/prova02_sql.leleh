create table departamentos (
    id_departamento int auto_increment primary key,
    
)