create table departamentos (
    id_departamento int auto_increment primary key,
    nome_departamento varchar(100),
    
)