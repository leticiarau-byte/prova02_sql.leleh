
drop techfactory_db;