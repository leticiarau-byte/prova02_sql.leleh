-- create table departamentos (
--     id_departamento int auto_increment primary key,
--     nome_departamento varchar(100),
--     localizacao_departamento varchar(100)
-- );

inserts departamentos (nome_departamento, localizacao_departamento) 
values
('produção','curitiba'),
('engenharia','sao paulo'),
('qualidade','floripa');

