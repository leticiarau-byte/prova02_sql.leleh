create table departamentos (
    
)