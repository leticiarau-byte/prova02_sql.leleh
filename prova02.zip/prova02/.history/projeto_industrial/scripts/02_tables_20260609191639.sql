create table departamentos (
    id_departamento int auto_increment primary key,
    nome_departamento varchar(100),
    localizacao_departamento varchar(100)
);

create table colaboladores (
    id_colaboladores int auto_increment primary key,
    nome_colaboladores varchar(100),
    cargo_colaboladores varchar(100),
    email_colaboladores varchar(100),
    data_admissao_colaboladores date,
    cpf_colaboladores varchar(14) unique not null
    
);

create table colaboladores (
    id_colaboladores int auto_increment primary key,
    nome_colaboladores varchar(100),
    cargo_colaboladores varchar(100),
    email_colaboladores varchar(100),
    data_admissao_colaboladores date,
    cpf_colaboladores varchar(14) unique not null
);


