create inserts departamentos () values
