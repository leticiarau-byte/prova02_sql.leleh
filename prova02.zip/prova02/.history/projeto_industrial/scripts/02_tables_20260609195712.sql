create table departamentos (
    id_departamento int auto_increment primary key,
    nome_departamento varchar(100),
    localizacao_departamento varchar(100)
);

create table colaboladores (
    id_colaboladores int auto_increment primary key,
    nome_colaboladores varchar(100),
    cargo_colaboladores varchar(100),
    email_colaboladores varchar(100) unique not null,
    data_admissao_colaboladores date,
    cpf_colaboladores varchar(14) unique not null,
    id_departamento int,
    FOREIGN KEY (id_departamento) REFERENCES departamentos(id_departamento)
);

create table chamado (
    id_chamado int auto_increment primary key,
    numero_chamado int unique not null,
    descricao_chamado varchar(100),
    prioridade_chamado varchar(100),
    status_chamado varchar(100),
    data_encerramento_chamado date,
    id_colaboladores int,

    FOREIGN KEY (id_colaboladores) REFERENCES colaboladores(id_colaboladores)
);

create table manutencao (
    id_manutencao int auto_increment primary key,
    custo_manutencao decimal(6,2),
    tempo_gasto_manutencao int,
    descricao_manutencao varchar(100),
    data_manutencao date,
    id_chamado int,
    FOREIGN KEY (id_chamado) REFERENCES chamado(id_chamado)
);

create table equipamentos (
    patrimonio_equipamentos int auto_increment primary key,
    descricao_equipamentos varchar(100),
    fabricantes_equipamentos varchar(100),
    status_equipamentos varchar(100),
    modelo_equipamentos varchar(100),
    data_aquisicao_equipamentos date,
    id_manutencao int,
    FOREIGN KEY (id_manutencao) REFERENCES manutencao(id_manutencao)
);


create table fornecedores (
    id_fornecedores int auto_increment primary key,
    nome_fornecedores varchar(100),
    cnpj_forncedores varchar(100) unique not null,
    razao_social_fornecedores varchar(100),
    telefone varchar(11) not null,
    cidade varchar(100),
    id_equipamentos int,
    FOREIGN KEY (patrimonio_equipamentos) REFERENCES equipamentos(id_equipamentos)
);

create table categorias (
    id_categorias int auto_increment primary key,
    nome_categoria varchar(100),
    id_fornecedores int,
    FOREIGN KEY (id_fornecedores) REFERENCES fornecedores(id_fornecedores)
);




