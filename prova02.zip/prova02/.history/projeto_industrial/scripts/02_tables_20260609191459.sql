create table departamentos (
    id_departamento int auto_increment primary key,
    nome_departamento varchar(100),
    localizacao_departamento varchar(100)
);

create table colaboladores (
    id_colaboladores int auto_increment primary key,
    nome varchar(100),
    localizacao_departamento varchar(100)
);