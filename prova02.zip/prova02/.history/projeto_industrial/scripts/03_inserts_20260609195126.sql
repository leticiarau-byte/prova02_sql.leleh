
create inserts departamentos () values
()
