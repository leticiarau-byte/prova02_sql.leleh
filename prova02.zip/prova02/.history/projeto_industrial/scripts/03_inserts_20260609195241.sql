create table departamentos (
    id_departamento int auto_increment primary key,
    nome_departamento varchar(100),
    localizacao_departamento varchar(100)
);

create inserts departamentos (nonome_departamento, localizacao_departamento ) values
()
