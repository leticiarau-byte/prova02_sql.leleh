create inserts departamentos ()
