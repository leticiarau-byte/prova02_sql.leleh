
drop techfactory_db;
use techfactory_db;